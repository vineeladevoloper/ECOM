﻿using System.ComponentModel.DataAnnotations;

namespace Flight.DTO
{
    public class CategoriesDTO
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
    }
}
