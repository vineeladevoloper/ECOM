﻿namespace Flight.DTO
{
  
        public class CartDTO
        {
            public int Id { get; set; }
            public int ProductId { get; set; }
            public int UserId { get; set; }
            public decimal price { get; set; }
            // Add any other properties as needed
        }
    }


