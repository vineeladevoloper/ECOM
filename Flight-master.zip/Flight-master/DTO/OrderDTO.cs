﻿namespace Flight.DTO
{
    public class OrderDTO
    {
        public int Id { get; set; }
        public int BillId { get; set; }
        public string OrderStatus { get; set; }
    }
}
