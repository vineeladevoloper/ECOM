﻿namespace Flight.DTO
{
    public class RatingDTO
    {
        public int Id { get; set; }
        public int Rating { get; set; }
        public string Feedback { get; set; }
        public int ProductId { get; set; }
        public int UserId { get; set; }

    }
}
