﻿using System.ComponentModel.DataAnnotations;

namespace Flight.Entity
{
    public class Order
    {
        [Key] // Specify Id as the primary key
        public int Id { get; set; }

        public int BillId { get; set; }

        public string OrderStatus { get; set; }


    }
}