﻿using System.ComponentModel.DataAnnotations;

namespace Flight.Entity
{
    public class Cart
    {
        [Key] // Specifies that Id is the primary key
        public int Id { get; set; }

        public int ProductId { get; set; }
        public int UserId { get; set; }
        public int Quantity { get; set; }

    }
}
