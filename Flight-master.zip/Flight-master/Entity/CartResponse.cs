﻿namespace Flight.Entity
{
    public class ProductsList
    {
        public products products { get; set; }
        public int quantity { get; set; }
    }
    public class CartResponse
    {
        public List<ProductsList> ProductItems {  get; set; }
        public decimal Price { get; set; }
    }
}
