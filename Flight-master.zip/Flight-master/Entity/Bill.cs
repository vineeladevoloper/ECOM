﻿using System.ComponentModel.DataAnnotations;

namespace Flight.Entities
{
    public class Bill
    {
        [Key]
        public int Id { get; set; }
        [Required]  
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
        public string ShippingAddress { get; set; }
    }
}
