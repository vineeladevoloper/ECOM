﻿using System.ComponentModel.DataAnnotations;

namespace Flight.Entity
{
 
        public class Categories
        {
            
            [Key] 
            public int Id { get; set; }            
            public string CategoryName { get; set; }
        }
    }
