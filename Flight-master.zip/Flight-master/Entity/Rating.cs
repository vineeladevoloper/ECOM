﻿using System.ComponentModel.DataAnnotations;

namespace Flight.Entity
{
    public class Rating
    {

        [Key]
        public int Id { get; set; }

        public int RatingValue { get; set; }

        public string Feedback { get; set; }

        public int ProductId { get; set; }

        public int UserId { get; set; }
    }
}
