﻿using System;
using System.Collections.Generic;
using System.Linq;
using Flight.Database; // Import the namespace where your MyContext class resides
using Flight.Entity;

namespace Flight.Services
{
    public class ProductService : Iproduct
    {
        private readonly Mycontext _dbContext; // Replace Mycontext with your actual DbContext

        public ProductService(Mycontext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AddProduct(products product)
        {
            _dbContext.Products.Add(product);
            _dbContext.SaveChanges();
        }

        public void UpdateProduct(products product)
        {
            var existingProduct = _dbContext.Products.Find(product.Id);
            if (existingProduct == null)
            {
                throw new InvalidOperationException("Product not found.");
            }

            // Update properties
            existingProduct.Name = product.Name;
            existingProduct.ImageUrl = product.ImageUrl;
            existingProduct.Description = product.Description;
            existingProduct.Price = product.Price;
            existingProduct.ProductEmail = product.ProductEmail;
            existingProduct.CategoryId = product.CategoryId;

            _dbContext.SaveChanges();
        }

        public void DeleteProduct(int ProductID)
        {
            var product = _dbContext.Products.Find(ProductID);
            if (product != null)
            {
                _dbContext.Products.Remove(product);
                _dbContext.SaveChanges();
            }
        }

        public products GetProductById(int ProductID)
        {
            return _dbContext.Products.Find(ProductID);
        }

        public List<products> GetAllProducts()
        {
            return _dbContext.Products.ToList();
        }

        public List<products> GetProductByName(string search)
        {
            return _dbContext.Products
                .Where(p => p.Name.Contains(search))
                .ToList();
        }
    }
}
