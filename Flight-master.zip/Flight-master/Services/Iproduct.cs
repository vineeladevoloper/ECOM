﻿using Flight.Entity;

namespace Flight.Services
{
    public interface Iproduct
    {
        void AddProduct(products product);

        void UpdateProduct(products product);

        void DeleteProduct(int ProductID);

        products GetProductById(int ProductID);

        List<products> GetAllProducts();

        List<products> GetProductByName(string search);


    }
}
