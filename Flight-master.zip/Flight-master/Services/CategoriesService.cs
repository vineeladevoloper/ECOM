﻿using Flight.Database;
using Flight.Entity;
using Flight.DTO;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;

namespace Flight.Services
{
    public class CategoryService : ICategory
    {
        private readonly Mycontext _context;
        private readonly IMapper _mapper;

        public CategoryService(Mycontext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public void AddCategory(Categories category)
        {
            try
            {
                if (category == null)
                {
                    throw new ArgumentNullException(nameof(category));
                }

                _context.categories.Add(category);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void UpdateCategory(Categories category)
        {
            try
            {
                if (category == null)
                {
                    throw new ArgumentNullException(nameof(category));
                }

                _context.categories.Update(category);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteCategory(int CategoryID)
        {
            try
            {
                var category = _context.categories.Find(CategoryID);
                if (category != null)
                {
                    _context.categories.Remove(category);
                    _context.SaveChanges();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Categories GetCategoryById(int CategoryID)
        {
            try
            {
                return _context.categories.FirstOrDefault(c => c.Id == CategoryID);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Categories> GetAllCategories()
        {
            try
            {
                return _context.categories.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Categories> GetCategoryByName(string search)
        {
            try
            {
                return _context.categories
                        .Where(c => c.CategoryName.Contains(search))
                        .ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}