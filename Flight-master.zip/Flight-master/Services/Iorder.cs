﻿using Flight.Entity;

namespace Flight.Services
{
    public interface Iorder
    {
        Order AddOrder(int userId);

        void UpdateOrder(Order order);

        void DeleteOrder(int orderId);

        Order GetOrderById(int orderId);

        List<Order> GetAllOrders();

        List<Order> GetOrdersByStatus(string status);

    }
}
