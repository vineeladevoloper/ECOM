﻿using Flight.Database;
using Flight.Entities;
using System.Security.Cryptography.X509Certificates;

namespace Flight.Services
{
    public class BillService: IBill
    {
        private readonly Mycontext _context;

        public BillService(Mycontext mycontext) { 
            _context = mycontext;
        }

        public Bill UpdateBill(Bill bill)
        {
            if (bill == null)
            {
                return null;
            }
            else
            {
            _context.bill.Update(bill);
            _context.SaveChanges();
            return bill;
            }
        }
    }
}
