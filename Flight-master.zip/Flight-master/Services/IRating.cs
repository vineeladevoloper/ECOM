﻿using System;
using System.Collections.Generic;
using Flight.Entity;

namespace Flight.Services
{
    public interface IRatingService
    {
        void AddRating(Rating rating);

        void UpdateRating(Rating rating);

        void DeleteRating(int ratingId);

        Rating GetRatingById(int ratingId);

        List<Rating> GetRatingByProduct(int productId);

        List<Rating> GetAllRatings();

        List<Rating> GetRatingsByProductId(int productId);
    }
}
