﻿using Flight.Entities;

namespace Flight.Services
{
    public interface IBill
    {
        Bill UpdateBill(Bill bill);
    }
}
