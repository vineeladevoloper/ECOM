﻿using System;
using System.Collections.Generic;
using System.Linq;
using Flight.Database;
using Flight.DTO;
using Flight.Entity;
using Microsoft.EntityFrameworkCore;

namespace Flight.Services
{
    public class CartService : ICart
    {
        private readonly Mycontext _context;

        public CartService(Mycontext context)
        {
            _context = context;
        }

        public Cart AddToCart(int productId, int userId, int quantity)
        {
            var cartItem = _context.cart.FirstOrDefault(c => c.ProductId == productId && c.UserId == userId);

            if (cartItem != null)
            {
                cartItem.Quantity += quantity;
                _context.cart.Update(cartItem);
            }
            else
            {
                cartItem = new Cart();
                cartItem.ProductId = productId;
                cartItem.UserId = userId;
                cartItem.Quantity = quantity;
                _context.cart.Add(cartItem);
            }

            _context.SaveChanges();
            return cartItem;
         }

        public void RemoveFromCart(int productId, int userId)
        {
            var cartItem = _context.cart.FirstOrDefault(c => c.ProductId == productId && c.UserId == userId);

            if (cartItem != null)
            {
                _context.cart.Remove(cartItem);
                _context.SaveChanges();
            }
        }

        public void ClearCart(int userId)
        {
            _context.cart.Where(c => c.UserId == userId).ToListAsync().Result.ForEach(c=>_context.cart.Remove(c));
            _context.SaveChanges();
        }

        public CartResponse GetCartItems(int userId)
        {
            List<Cart> cartItems = _context.cart.Where(c => c.UserId == userId).ToListAsync().Result;
            List<ProductsList> products = new List<ProductsList>();
            foreach (var cartItem in cartItems) {
                products.Add(new ProductsList { products = _context.Products.FindAsync(cartItem.ProductId).Result, quantity = cartItem.Quantity });
            }
            CartResponse cartResponse = new CartResponse { ProductItems = products, Price = cartItems.Sum(c => c.Quantity * _context.Products.FindAsync(c.ProductId).Result.Price)};
            return cartResponse;
        }
         

        public void UpdateCartItemQuantity(int productId, int newQuantity)
        {
            var cartItem = _context.cart.FirstOrDefault(c => c.ProductId == productId);

            if (cartItem != null)
            {
                cartItem.Quantity = newQuantity;     
                _context.cart.Update(cartItem);
                _context.SaveChanges();
            }
        }
    }
}
  