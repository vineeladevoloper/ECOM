﻿using Flight.DTO;
using Flight.Entity;

namespace Flight.Services
{
    public interface ICart
    {

        Cart AddToCart(int productId, int userId, int quantity);
        void RemoveFromCart(int productId, int userId);
        void ClearCart(int userId);
        CartResponse GetCartItems(int userId);
        void UpdateCartItemQuantity(int productId, int newQuantity);
    }
}
