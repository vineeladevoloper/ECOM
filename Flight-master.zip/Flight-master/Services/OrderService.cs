﻿using System;
using System.Collections.Generic;
using System.Linq;
using Flight.Database;
using Flight.Entities;
using Flight.Entity;
using Microsoft.EntityFrameworkCore;

namespace Flight.Services
{
    public class OrderService : Iorder
    {
        private readonly Mycontext _context;

        public OrderService(Mycontext context)
        {
            _context = context;
        }

        public Order AddOrder(int userId)
        {
            if (userId == null)
            {
                throw new ArgumentNullException(nameof(userId));
            }
            Order order = new Order();
            User user = _context.Users.FindAsync(userId).Result;
            if (user != null) {
            Bill bill = new Bill();
            bill.UserId = userId;
            bill.Amount = _context.cart.Where(c=>c.UserId == userId).ToListAsync().Result.Sum(c => c.Quantity * _context.Products.FindAsync(c.ProductId).Result.Price);
            bill.PaymentMethod = "Credit Card";
            bill.PaymentStatus = "Paid";
            bill.UserName = user.UserName;
            bill.UserEmail = user.Email;
            bill.ShippingAddress = user.Address;

            _context.bill.Add(bill);
            _context.SaveChanges();
            }
            else
            {
                return null;
            }
            int billId = _context.bill.FindAsync(userId).Result.Id;
            if(billId != null) {
            order.BillId = billId;
            order.OrderStatus = "Order Placed Succesfully!";
            _context.orders.Add(order);
            _context.SaveChanges();
            }
            else
            {
                return null;
            }
            return order;

        }

        public void UpdateOrder(Order order)
        {
            if (order == null)
            {
                throw new ArgumentNullException(nameof(order));
            }

            _context.orders.Update(order);
            _context.SaveChanges();
        }

        public void DeleteOrder(int orderId)
        {
            var order = _context.orders.Find(orderId);
            if (order != null)
            {
                _context.orders.Remove(order);
                _context.SaveChanges();
            }
        }

        public Order GetOrderById(int orderId)
        {
            return _context.orders.Find(orderId);
        }

        public List<Order> GetAllOrders()
        {
            return _context.orders.ToList();
        }

        public List<Order> GetOrdersByStatus(string status)
        {
            return _context.orders.Where(o => o.OrderStatus == status).ToList();
        }
    }
}
