﻿using System;
using System.Collections.Generic;
using System.Linq;
using Flight.Database;
using Flight.Entity;
using Microsoft.EntityFrameworkCore;

namespace Flight.Services
{
    public class RatingService : IRatingService
    {
        private readonly Mycontext _context;

        public RatingService(Mycontext context)
        {
            _context = context;
        }

        public void AddRating(Rating rating)
        {
            if (rating == null)
            {
                throw new ArgumentNullException(nameof(rating));
            }

            _context.rating.Add(rating);
            _context.SaveChanges();
        }

        public void UpdateRating(Rating rating)
        {
            if (rating == null)
            {
                throw new ArgumentNullException(nameof(rating));
            }

            _context.rating.Update(rating);
            _context.SaveChanges();
        }

        public void DeleteRating(int ratingId)
        {
            var rating = _context.rating.Find(ratingId);
            if (rating != null)
            {
                _context.rating.Remove(rating);
                _context.SaveChanges();
            }
        }

        public Rating GetRatingById(int ratingId)
        {
            return _context.rating.Find(ratingId);
        }

        public List<Rating> GetRatingByProduct(int productId)
        {
            return _context.rating.Where(r=>r.ProductId == productId).ToListAsync().Result;
        }

        public List<Rating> GetAllRatings()
        {
            return _context.rating.ToList();
        }

        public List<Rating> GetRatingsByProductId(int productId)
        {
            return _context.rating.Where(r => r.ProductId == productId).ToList();
        }
    }
}
