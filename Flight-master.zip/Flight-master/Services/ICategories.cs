﻿using Flight.Entity;

namespace Flight.Services
{
    public interface ICategory
    {
        void AddCategory(Categories category);

        void UpdateCategory(Categories category);

        void DeleteCategory(int CategoryID);

        Categories GetCategoryById(int CategoryID);

        List<Categories> GetAllCategories();

        List<Categories> GetCategoryByName(string search);
    }
}
