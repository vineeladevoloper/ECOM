﻿namespace Flight.Models
{
        public class AuthReponse
        {
            public int? UserId { get; set; }
            public string UserName { get; set; }
            public string Role { get; set; }
            public string Token { get; set; }
        }
    }


