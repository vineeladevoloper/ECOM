﻿using AutoMapper;
using Flight.Entities;
using Flight.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Flight.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BillController : ControllerBase
    {
        private readonly IBill _billService;

        public BillController(IBill billService)
        {
            _billService = billService;
        }

        [HttpPut]
        public IActionResult UpdateBillStatus([FromBody] Bill bill)
        {
            if (bill == null)
            {
                return BadRequest("Invalid bill data");
            }

            Bill updatedBill = _billService.UpdateBill(bill);
            if (updatedBill == null)
            {
                return StatusCode(500, "Something went wrong!");
            }

            return Ok(updatedBill);
        }
    }
}
