﻿using Microsoft.AspNetCore.Mvc;
using Flight.DTO;
using Flight.Services;
using AutoMapper;
using Flight.Entity;

namespace Flight.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategory _categoryService;
        private readonly IMapper _mapper;

        public CategoriesController(ICategory categoryService, IMapper mapper)
        {
            _categoryService = categoryService;
            _mapper = mapper;
        }

        [HttpPost]
        public IActionResult AddCategory([FromBody] CategoriesDTO categoryDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingCategory = _categoryService.GetCategoryById(categoryDTO.Id);
            if (existingCategory != null)
            {
                return Conflict("Category with the same ID already exists.");
            }

            var category = _mapper.Map<Categories>(categoryDTO);
            _categoryService.AddCategory(category);
            var categoryResponse = _mapper.Map<CategoriesDTO>(category);
            return CreatedAtAction(nameof(GetCategoryById), new { id = categoryResponse.Id }, categoryResponse);
        }

        [HttpGet("{id}")]
        public IActionResult GetCategoryById(int id)
        {
            var category = _categoryService.GetCategoryById(id);
            if (category == null)
            {
                return NotFound();
            }

            var categoryDTO = _mapper.Map<CategoriesDTO>(category);
            return Ok(categoryDTO);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCategory(int id, [FromBody] CategoriesDTO categoryDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingCategory = _categoryService.GetCategoryById(id);
            if (existingCategory == null)
            {
                return NotFound();
            }

            categoryDTO.Id = id; // Ensure the ID in the DTO matches the requested ID
            var category = _mapper.Map<Categories>(categoryDTO);
            _categoryService.UpdateCategory(category);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCategory(int id)
        {
            var category = _categoryService.GetCategoryById(id);
            if (category == null)
            {
                return NotFound();
            }

            _categoryService.DeleteCategory(id);
            return NoContent();
        }

        [HttpGet]
        public IActionResult GetAllCategories()
        {
            var categories = _categoryService.GetAllCategories();
            var categoryDTOs = _mapper.Map<List<CategoriesDTO>>(categories);
            return Ok(categoryDTOs);
        }

        [HttpGet("search")]
        public IActionResult GetCategoriesByName([FromQuery] string search)
        {
            var categories = _categoryService.GetCategoryByName(search);
            var categoryDTOs = _mapper.Map<List<CategoriesDTO>>(categories);
            return Ok(categoryDTOs);
        }
    }
}
