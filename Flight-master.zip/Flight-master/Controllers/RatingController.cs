﻿using AutoMapper;
using Flight.DTO;
using Flight.Entity;
using Flight.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Flight.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RatingController : ControllerBase
    {
        private readonly IRatingService _ratingService;
        private readonly IMapper _mapper;

        public RatingController(IRatingService ratingService, IMapper mapper)
        {
            _ratingService = ratingService;
            _mapper = mapper;
        }

        [HttpPost]
        public IActionResult AddRating([FromBody] RatingDTO ratingDTO)
        {
            if (ratingDTO == null)
            {
                return BadRequest("Rating data is null.");
            }

            var rating = _mapper.Map<Rating>(ratingDTO);

            _ratingService.AddRating(rating);

            return CreatedAtAction(nameof(GetRatingById), new { ratingId = rating.Id }, rating);
        }

        [HttpGet("{ratingId}")]
        public IActionResult GetRatingById(int ratingId)
        {
            var rating = _ratingService.GetRatingById(ratingId);
            if (rating == null)
            {
                return NotFound();
            }
            return Ok(rating);
        }

        [HttpGet("product/{productId}")] // Modified route template
        public IActionResult GetRatingByProductId(int productId)
        {
            List<Rating> ratings = _ratingService.GetRatingByProduct(productId);
            return Ok(ratings);
        }


        [HttpGet] // Removed route template for this method
        public IActionResult GetAllRatings()
        {
            var ratings = _ratingService.GetAllRatings();
            var ratingDTOs = _mapper.Map<List<RatingDTO>>(ratings);
            return Ok(ratingDTOs);
        }

        [HttpPut("{ratingId}")]
        public IActionResult UpdateRating(int ratingId, [FromBody] RatingDTO ratingDTO)
        {
            if (ratingDTO == null)
            {
                return BadRequest("Rating data is null.");
            }

            var existingRating = _ratingService.GetRatingById(ratingId);
            if (existingRating == null)
            {
                return NotFound();
            }

            _mapper.Map(ratingDTO, existingRating);

            _ratingService.UpdateRating(existingRating);

            return NoContent();
        }

        [HttpDelete("{ratingId}")]
        public IActionResult DeleteRating(int ratingId)
        {
            var existingRating = _ratingService.GetRatingById(ratingId);
            if (existingRating == null)
            {
                return NotFound();
            }

            _ratingService.DeleteRating(ratingId);

            return NoContent();
        }
    }
}
