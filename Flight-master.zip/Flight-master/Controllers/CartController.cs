﻿using Flight.Services;
using Microsoft.AspNetCore.Mvc;

namespace Flight.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICart _cartService;

        public CartController(ICart cartService)
        {
            _cartService = cartService;
        }

        [HttpPost("AddToCart")]
        public IActionResult AddToCart(int productId, int userId, int quantity)
        {
            var cart = _cartService.AddToCart(productId, userId, quantity);
            return StatusCode(200,cart);
        }

        [HttpDelete("RemoveFromCart")]
        public IActionResult RemoveFromCart(int productId, int userId)
        {
            _cartService.RemoveFromCart(productId, userId);
            return StatusCode(200, "Removed from cart successfully!");
        }

        [HttpDelete("ClearCart")]
        public IActionResult ClearCart(int userId)
        {
            _cartService.ClearCart(userId);
            return StatusCode(200,"Cart is cleared!");
        }

        [HttpGet("GetCartItems")]
        public IActionResult GetCartItems(int userId)
        {
            var cartItems = _cartService.GetCartItems(userId);
            return Ok(cartItems);
        }


        [HttpPut("UpdateCartItemQuantity")]
        public IActionResult UpdateCartItemQuantity(int productId, int newQuantity)
        {
            _cartService.UpdateCartItemQuantity(productId, newQuantity);
            return Ok();
        }
    }
}
