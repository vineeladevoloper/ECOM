﻿using Microsoft.AspNetCore.Mvc;
using Flight.Services;
using Flight.Entity;
using Flight.DTO; // Import the DTO namespace where your DTOs reside
using AutoMapper;

namespace Flight.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly Iproduct _productService;
        private readonly IMapper _mapper;

        public ProductController(Iproduct productService, IMapper mapper)
        {
            _productService = productService;
            _mapper = mapper;
        }

        [HttpPost]
        public IActionResult AddProduct([FromBody] ProductDTO productDTO)
        {
            var product = _mapper.Map<products>(productDTO);
            _productService.AddProduct(product);
            return StatusCode(200,product);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateProduct(int id, [FromBody] ProductDTO productDTO)
        {
            var product = _mapper.Map<products>(productDTO);
            product.Id = id;
            _productService.UpdateProduct(product);
            return Ok("Product updated successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            _productService.DeleteProduct(id);
            return StatusCode(200,"Product Deleted Successfully!");
        }

        [HttpGet("{id}")]
        public IActionResult GetProductById(int id)
        {
            var product = _productService.GetProductById(id);
            if (product == null)
            {
                return NotFound("Product not found");
            }
            var productDTO = _mapper.Map<ProductDTO>(product);
            return Ok(productDTO);
        }

        [HttpGet]
        public IActionResult GetAllProducts()
        {
            var products = _productService.GetAllProducts();
            var productDTOs = _mapper.Map<List<ProductDTO>>(products);
            return Ok(productDTOs);
        }

        [HttpGet("search")]
        public IActionResult GetProductByName([FromQuery] string search)
        {
            var products = _productService.GetProductByName(search);
            var productDTOs = _mapper.Map<List<ProductDTO>>(products);
            return Ok(productDTOs);
        }
    }
}
