﻿using System;
using System.Collections.Generic;
using Flight.DTO;
using Flight.Entity;
using Flight.Services;
using Microsoft.AspNetCore.Mvc;

namespace Flight.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly Iorder _orderService;

        public OrderController(Iorder orderService)
        {
            _orderService = orderService ?? throw new ArgumentNullException(nameof(orderService));
        }

        [HttpPost]
        public IActionResult AddOrder(int userId)
        {
            if (userId == null)
            {
                return BadRequest("Order data is null.");
            }
            Order order = _orderService.AddOrder(userId);
            if(order == null)
            {
                return StatusCode(500, "Something went Wrong!");
            }
            return Ok(order);
        }

        [HttpGet("{orderId}")]
        public IActionResult GetOrderById(int orderId)
        {
            var order = _orderService.GetOrderById(orderId);
            if (order == null)
            {
                return NotFound();
            }

            return Ok(order);
        }

        [HttpGet]
        public IActionResult GetAllOrders()
        {
            var orders = _orderService.GetAllOrders();
            return Ok(orders);
        }

        [HttpPut("{orderId}")]
        public IActionResult UpdateOrder(int orderId, [FromBody] OrderDTO orderDTO)
        {
            if (orderDTO == null)
            {
                return BadRequest("Order data is null.");
            }

            var existingOrder = _orderService.GetOrderById(orderId);
            if (existingOrder == null)
            {
                return NotFound();
            }

            // You can use AutoMapper to map OrderDTO to Order entity
            existingOrder.BillId = orderDTO.BillId;
            existingOrder.OrderStatus = orderDTO.OrderStatus;

            _orderService.UpdateOrder(existingOrder);

            return NoContent();
        }

        [HttpDelete("{orderId}")]
        public IActionResult DeleteOrder(int orderId)
        {
            var existingOrder = _orderService.GetOrderById(orderId);
            if (existingOrder == null)
            {
                return NotFound();
            }

            _orderService.DeleteOrder(orderId);

            return NoContent();
        }
    }
}
