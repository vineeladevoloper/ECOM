﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Flight.Entity;
using AutoMapper;
using Flight.Entities;
namespace Flight.Database
{
        public class Mycontext : DbContext
        {

        public Mycontext(DbContextOptions<Mycontext> options) : base(options)
            {
            }
            public DbSet<User> Users { get; set; }
            public DbSet<products> Products { get; set; }
            public DbSet<Categories> categories { get; set; }
            public DbSet<Order> orders { get; set; }
            public DbSet<Rating> rating { get; set; }
            public DbSet<Cart> cart { get; set; }
            public DbSet<Bill> bill { get; set; }
            
        }
    }
