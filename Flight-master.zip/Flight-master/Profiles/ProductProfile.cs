﻿using AutoMapper;
using Flight.DTO;
using Flight.Entity;

namespace Flight.Profiles
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<products, ProductDTO>();
            CreateMap<ProductDTO, products>();
        }
    }
}
