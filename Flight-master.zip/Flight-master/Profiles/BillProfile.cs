﻿using AutoMapper;
using Flight.DTO;
using Flight.Entities; // corrected namespace

namespace Flight.Profiles
{
    public class BillProfile : Profile // corrected inheritance
    {
        public BillProfile()
        {
            CreateMap<Bill, BillDTO>();
            CreateMap<BillDTO, Bill>();
        }
    }
}
