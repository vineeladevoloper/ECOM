﻿using AutoMapper;
using Flight.DTO;
using Flight.Entity;

namespace Flight.Profiles
{
    public class CartProfile : Profile
    {
        public CartProfile()
        {
            CreateMap<Cart, CartDTO>();
            CreateMap<CartDTO, Cart>();
        }
    }
}