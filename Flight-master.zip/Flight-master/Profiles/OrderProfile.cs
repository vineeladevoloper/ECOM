﻿using AutoMapper;
using Flight.DTO;
using Flight.Entity;

namespace Flight.Profiles
{
    public class OrderProfile : Profile
    {
        public OrderProfile()
        {
            CreateMap<OrderDTO, Order>(); 
            CreateMap<Order, OrderDTO>(); 
        }
    }
}
