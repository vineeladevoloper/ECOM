﻿using AutoMapper;
using Flight.DTO;
using Flight.Entity;

namespace Flight.Profiles
{
    public class RatingProfile : Profile
    {
        public RatingProfile()
        {
            CreateMap<RatingDTO, Rating>(); 
            CreateMap<Rating, RatingDTO>(); 
        }
    }
}
